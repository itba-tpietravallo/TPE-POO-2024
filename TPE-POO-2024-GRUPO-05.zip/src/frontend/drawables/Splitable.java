package frontend.drawables;

public interface Splitable {
    Drawable[] split();
}
