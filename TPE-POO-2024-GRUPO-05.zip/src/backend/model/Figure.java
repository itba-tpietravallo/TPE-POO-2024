package backend.model;

public interface Figure extends Movable {
    boolean pointBelongs(Point p);
}
