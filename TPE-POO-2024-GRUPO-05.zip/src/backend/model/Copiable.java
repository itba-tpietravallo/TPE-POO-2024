package backend.model;

public interface Copiable<T> {
    T getCopy();
}
